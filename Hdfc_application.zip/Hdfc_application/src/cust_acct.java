import java.io.BufferedReader;
import java.io.InputStreamReader;

public class cust_acct   
{
         final int max_limit=20;
         final  int min_limit=1;
         final double min_bal=500;
         private  String name[]=new String[20];
         private int accNo[]=new int[20];
         private double balAmt[]=new double[20];
         static int totRec=0;
        
        public void initialize()
        {
             for(int i=0;i<max_limit;i++)
             {
                name[i]="";
                accNo[i]=0;
                balAmt[i]=0.0;
            }
        }

        public void newEntry()
        {
               String str;
               int acno;
               double amt;
               boolean permit;
                permit=true;

               if (totRec>max_limit)
               {
                    System.out.println("\n\n\nSorry we cannot admit you in our bank...\n\n\n");
                    permit=false;
               }

               if(permit = true)  
               {
               totRec++;                        
               System.out.println("\n\n INSERTING NEW ENTRY");
               try{
                          accNo[totRec]=totRec;    
                        System.out.println("Account Number-->  "+accNo[totRec]);
                        
                     BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
                     System.out.print("Enter Name-->  ");
                     System.out.flush();
                     name[totRec]=obj.readLine();
                    do{
                           System.out.print("Enter Initial  Amount to be deposited (As per bank rule)--> ");
                           System.out.flush();
                           str=obj.readLine();
                           balAmt[totRec]=Double.parseDouble(str);
                         }while(balAmt[totRec]<min_bal);      

                  System.out.println("\n\n\n");
                    }
                catch(Exception e)
                {}
            }
        }
         public void display()
        {
              String str;
              int acno=0;
              boolean valid=true;
                           
              System.out.println("\n\nDETAILS AS FOLLOWS\n");
              try{
                 BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
                 System.out.print("Enter Account number--> ");
                 System.out.flush();
                 str=obj.readLine();
                 acno=Integer.parseInt(str);
                  if (acno<min_limit  || acno>totRec)   
                     {
                          System.out.println("\n\n\nInvalid Account Number!!!!!!!! \n\n");
                          valid=false;
                     }

                    if (valid==true)
                      {     
                        System.out.println("\n\nAccount Number--> "+accNo[acno]);
                        System.out.println("Account holder Name--> "+name[acno]);
                        System.out.println("Balance Amount--> "+balAmt[acno]+"\n\n\n");
                      }
                 }
            catch(Exception e)
            {}
        }



        public void deposit()
        {
              String str;
              double amt;
              int acno;
              boolean valid=true;
              System.out.println("\n\n\nDEPOSIT AMOUNT MENU");
              
              try{
                   
                   BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));

                        System.out.print("Enter Account No--> ");
                        System.out.flush();
                        str=obj.readLine();
                        acno=Integer.parseInt(str);
                         if (acno<min_limit || acno>totRec)   
                         {
                              System.out.println("\n\n\nInvalid Account Number !!!!!! \n\n");
                              valid=false;
                         }
           
                        if (valid==true)
                       {
                            System.out.print("Please Enter Amount you want to DeposiT--> ");
                            System.out.flush();
                            str=obj.readLine();
                            amt=Double.parseDouble(str);

                            balAmt[acno]=balAmt[acno]+amt;
                           
                            System.out.println("\nAfter Updation...");
                            System.out.println("Account Number--> "+acno);
                            System.out.println("Balance Amount--> "+balAmt[acno]+"\n\n\n");
                        }
                 }
            catch(Exception e)
            {}
       }
    
         public void withdraw()
        {
              String str;
              double amt,checkamt,penalty;
              int acno;
              boolean valid=true;
              System.out.println("\n\n\nWITHDRAW AMOUNT MENU");
              
              try{
                   
                   BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
                   
                        System.out.print("Enter Account No--> ");
                        System.out.flush();
                        str=obj.readLine();
                        acno=Integer.parseInt(str);

                          if (acno<min_limit || acno>totRec)   
                             {
                                System.out.println("\n\n\nInvalid Account Number!!!! \n\n");
                                valid=false;
                            }

                        if (valid==true)
                        {
                                System.out.println("Balance is--> "+balAmt[acno]);
                                System.out.print("Enter Amount you want to withdraw-->");
                                System.out.flush();
                                str=obj.readLine();
                                amt=Double.parseDouble(str);
                                
                                if(amt <= balAmt[acno])
                                {
                                checkamt=balAmt[acno]-amt;
                                balAmt[acno]=checkamt;
                                System.out.println("\nAfter Updation");
                                System.out.println("Account Number--> "+acno);
                                System.out.println("Balance Amount--> "+balAmt[acno]+"\n\n\n");
                                }
                                else
                                {
                                	System.out.println("\n\nTransaction failed due to LOW balance");
                                }
                        }
                 }
            catch(Exception e)
            {}
       }

}
