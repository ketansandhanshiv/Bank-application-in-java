import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Bank_improved {


    public static void main(String args[]) 
    {
        String str;
        int choice=0,quit;
  
        cust_acct curr_obj = new cust_acct();
        System.out.println("\n WELLCOME TO HDFC BANK \n");
        
        do//For Current Account
        {
        System.out.println("\n\n Enter Your Choices ...");
        System.out.println("#1. New Record Entry ");
        System.out.println("#2. Display Record Details ");
        System.out.println("#3. Deposit...");
        System.out.println("#4. Withdraw...");
        System.out.println("#5. Quit");
         System.out.print("Enter your choice :  ");
        System.out.flush();
              try{
                   BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
                   str=obj.readLine();
                   choice=Integer.parseInt(str);

                          switch(choice)
                           {
                            case 1 :  //New Record Entry
                                            curr_obj.newEntry();
                                           break;
                            case 2 :  //Displaying Record Details
                                           curr_obj.display();
                                           break;
                            case 3 : //Deposit...
                                            curr_obj.deposit();
                                           break;
                            case 4 : //Withdraw...
                                            curr_obj.withdraw();
                                            break;
                            case 5  :  System.out.println("\n\n.....Thank you .....");
                            			System.out.println("\n....VISIT AGAIN....");
                                            
                            		break;
                            default : System.out.println("\nInvalid Choice \n\n");
                          }
                    }
                catch(Exception e)
                {}
            }while(choice!=5);
    
		try{
		BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("\nEnter 1 for Exit : ");
		System.out.flush();
		str=obj.readLine();
		quit=Integer.parseInt(str);
		}catch (Exception e){}
		}
  }
