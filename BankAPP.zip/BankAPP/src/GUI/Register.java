package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.nio.channels.SelectableChannel;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Register {
	
	JFrame frame;
	JButton b1, b2;
	JTextField t1,t2,t3,t4,t5;
	JLabel l1,l2,l3,l4,l5;
	JPanel pan;
	
	public Register(){
		
		frame = new JFrame("Registration Page");
		
		pan = new JPanel();
		pan.setBounds(40,40,600,600);
		pan.setBackground(Color.LIGHT_GRAY);
		
		
		l1= new JLabel("User Name");
		l1.setBounds(25,10,100,100);
		
		l2= new JLabel("Customer ID");
		l2.setBounds(25,70,100,100);
		
		l3= new JLabel("Contact No.");
		l3.setBounds(25,140,100,100);
		
		l4= new JLabel("Account No.");
		l4.setBounds(25,200,100,100);
		
		l5= new JLabel("City");
		l5.setBounds(25,260,100,100);
		
	
		
		
		b1= new JButton("Cancel");
		b1.setBounds(40,360,150,50);
		b2= new JButton("OK");
		b2.setBounds(230,360,150,50);
		
		
		

		t1 = new JTextField(20);
		t1.setBounds(170,45,170,30);
		
		t2 = new JTextField(20);
		t2.setBounds(170,110,170,30);
		
		t3 = new JTextField(20);
		t3.setBounds(170,175,170,30);
		
		t4 = new JTextField(20);
		t4.setBounds(170,240,170,30);
		
		t5 = new JTextField(20);
		t5.setBounds(170,305,170,30);
		
		
		
		pan.add(l1);
		pan.add(t1);
		pan.add(l2);
		pan.add(t2);
		pan.add(l3);
		pan.add(t3);
		pan.add(l4);
		pan.add(t4);
		pan.add(l5);
		pan.add(t5);
		pan.add(b1);
		pan.add(b2);
        pan.setLayout(null);
		pan.setSize(420, 420);
		frame.add(pan);
		
		
		frame.setLayout(null);
		
		frame.setSize(520, 520);
		frame.setVisible(true);
		
		
	}
	
	
	




public static void main(String args[]){
	
	new Register(); 
	
	
}
}


